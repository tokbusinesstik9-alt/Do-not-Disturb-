import Link from "next/link";
import { ShoppingBag, MessageCircle, Wallet, Truck, ShieldCheck, ArrowRight } from "lucide-react";

const features = [
  ["Marketplace","Browse products and services from sellers.",ShoppingBag],
  ["Messaging","Chat with sellers and customers.",MessageCircle],
  ["Wallet & history","View wallet activity and transaction records.",Wallet],
  ["Order tracking","Follow order and delivery status updates.",Truck],
  ["Safer transactions","Payment status is verified on the server.",ShieldCheck]
] as const;

export default function Home() {
  return <main>
    <nav className="nav"><div className="brand"><span className="mark">D</span> DND <span className="muted">MARKETPLACE</span></div><div className="navlinks"><Link href="/login">Log in</Link><Link className="button small" href="/register">Create account</Link></div></nav>
    <section className="hero">
      <div className="eyebrow">DO NOT DISTURB MARKETPLACE</div>
      <h1>Everything you need.<br/><span>One marketplace.</span></h1>
      <p>Discover everyday goods and services, connect with sellers, and keep your orders in one place.</p>
      <div className="actions"><Link className="button" href="/register">Get started <ArrowRight size={17}/></Link><Link className="button secondary" href="/marketplace">Explore marketplace</Link></div>
      <div className="heroNote">Built for customers and sellers · Nigeria-first</div>
    </section>
    <section className="features"><div className="sectionHead"><div className="eyebrow">THE PLATFORM</div><h2>Marketplace tools in one place</h2></div><div className="grid">{features.map(([name,desc,Icon])=><article className="feature" key={name}><div className="featureIcon"><Icon size={21}/></div><h3>{name}</h3><p>{desc}</p></article>)}</div></section>
    <footer>© {new Date().getFullYear()} DND Marketplace <span>Support: 08075544025</span></footer>
  </main>;
}
