import "./globals.css";
import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "DND Marketplace",
  description: "DO NOT DISTURB Marketplace"
};
export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>{children}</body></html>;
}
