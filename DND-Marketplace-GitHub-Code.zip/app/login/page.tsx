 "use client";
import Link from "next/link";
import {useState} from "react";
import {supabase} from "@/lib/supabase";
export default function Login(){const[email,setEmail]=useState("");const[password,setPassword]=useState("");const[msg,setMsg]=useState("");const[busy,setBusy]=useState(false);
async function submit(e:React.FormEvent){e.preventDefault();setBusy(true);setMsg("");const{error}=await supabase.auth.signInWithPassword({email,password});setBusy(false);setMsg(error?.message??"Signed in. You can now open your dashboard.");}
return <main className="page"><Link href="/">← DND Marketplace</Link><div className="panel" style={{maxWidth:460,margin:"45px auto"}}><h1>Welcome back</h1><p className="notice">Log in to your DND account.</p><form onSubmit={submit}><label className="label">Email</label><input className="field" type="email" required value={email} onChange={e=>setEmail(e.target.value)}/><label className="label">Password</label><input className="field" type="password" required value={password} onChange={e=>setPassword(e.target.value)}/><button className="button" disabled={busy}>{busy?"Please wait…":"Log in"}</button></form>{msg&&<p className="notice">{msg}</p>}<p className="notice">New here? <Link href="/register">Create an account</Link></p></div></main>}
