# DND Marketplace — source-code foundation

This is a real Next.js + Supabase project foundation for DND Marketplace. It is not a completed production marketplace yet. It includes the website shell, Supabase client, email/password registration and login, public active-listing query, health endpoint, and an initial database schema with Row Level Security.

## Stack
- GitHub: source-code repository
- Render: web hosting and server runtime
- Supabase: authentication, Postgres database, realtime and storage
- Flutterwave: intended payment provider (bank transfer and online banking only, subject to provider account/method availability)

## 1. Set up Supabase
1. Create/open your Supabase project.
2. Open **SQL Editor**.
3. Paste and run `supabase/schema.sql`.
4. In **Project Settings → API**, copy the Project URL and anon/public key.
5. Set these as Render environment variables:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`

Never put the Supabase `service_role` key or Flutterwave secret key in browser code or commit them to GitHub.

## 2. Upload to GitHub
Create a new repository named `dnd-marketplace`, upload all files/folders in this project, and commit to the main branch.

## 3. Deploy on Render
1. In Render choose **New → Web Service** and connect the GitHub repository.
2. Runtime: Node.
3. Build command: `npm install && npm run build`
4. Start command: `npm start`
5. Add the two Supabase public environment variables above.
6. Deploy. Check `/api/health`.

## 4. Supabase Auth
In Supabase **Authentication → URL Configuration**, add your deployed Render URL to Site URL and Redirect URLs. Email/password signup is wired in the included pages. Google/phone sign-in requires configuring the relevant Supabase providers and credentials first.

## Important unfinished production integrations
This source is a foundation, not a claim that every requested feature is already live. Before launch, implement and test:
- Flutterwave checkout creation, signed webhook verification and server-side payment verification.
- Server-only wallet ledger posting, refunds, withdrawals and 10% commission settlement.
- Product create/edit/image upload and admin moderation.
- Order checkout, seller fulfilment, courier API integration and delivery events.
- Realtime chat subscriptions, group creation, membership authorization, blocking/reporting and presence.
- Subscription billing (Elite ₦5,000/month; VIL ₦10,000/month), referral qualification (₦200 subject to the stated eligibility), and paid ₦500 support tickets.
- Admin authorization, audit trail, dispute/refund handling and abuse controls.
- Legal terms, privacy policy, security review, backups and end-to-end testing.

The schema includes the main data tables, but a schema alone does not implement a payment provider, courier API or production workflow. Do not accept screenshots/receipts as payment proof. Mark payments successful only after server-side provider verification and a verified webhook.
