-- DND Marketplace starter schema. Run in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text,
 role text not null default 'customer' check (role in ('customer','seller','admin')),
 country text not null default 'Nigeria',
 currency text not null default 'NGN',
 avatar_url text,
 is_online boolean not null default false,
 last_seen timestamptz,
 created_at timestamptz not null default now()
);

create table if not exists public.products (
 id uuid primary key default gen_random_uuid(),
 seller_id uuid not null references public.profiles(id) on delete cascade,
 title text not null,
 description text,
 category text not null,
 price numeric(14,2) not null check(price > 0),
 currency text not null default 'NGN',
 status text not null default 'pending' check(status in ('pending','active','rejected','removed','sold_out')),
 created_at timestamptz not null default now()
);

create table if not exists public.orders (
 id uuid primary key default gen_random_uuid(),
 customer_id uuid not null references public.profiles(id),
 seller_id uuid not null references public.profiles(id),
 product_id uuid references public.products(id),
 amount numeric(14,2) not null check(amount > 0),
 currency text not null default 'NGN',
 payment_status text not null default 'pending' check(payment_status in ('pending','successful','failed','refunded')),
 delivery_status text not null default 'awaiting_payment' check(delivery_status in ('awaiting_payment','confirmed','preparing','dispatched','in_transit','delivered','delayed','cancelled','returned')),
 tracking_number text,
 courier_name text,
 created_at timestamptz not null default now()
);

create table if not exists public.wallets (
 user_id uuid primary key references public.profiles(id) on delete cascade,
 currency text not null default 'NGN',
 -- Balance must be changed only by trusted server-side payment/settlement functions.
 balance numeric(14,2) not null default 0 check(balance >= 0),
 updated_at timestamptz not null default now()
);

create table if not exists public.wallet_transactions (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id),
 order_id uuid references public.orders(id),
 type text not null check(type in ('deposit','withdrawal','purchase','sale_earning','commission','referral_reward','support_fee','subscription','refund')),
 amount numeric(14,2) not null,
 currency text not null default 'NGN',
 status text not null default 'pending' check(status in ('pending','successful','failed','reversed')),
 reference text unique,
 description text,
 created_at timestamptz not null default now()
);

create table if not exists public.payment_intents (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id),
 order_id uuid references public.orders(id),
 provider text not null default 'flutterwave',
 provider_reference text unique,
 amount numeric(14,2) not null check(amount > 0),
 currency text not null default 'NGN',
 method text not null check(method in ('bank_transfer','online_banking')),
 status text not null default 'pending' check(status in ('pending','successful','failed','refunded')),
 verified_at timestamptz,
 created_at timestamptz not null default now()
);

create table if not exists public.conversations (
 id uuid primary key default gen_random_uuid(),
 title text,
 is_group boolean not null default false,
 created_by uuid references public.profiles(id),
 created_at timestamptz not null default now()
);
create table if not exists public.conversation_members (
 conversation_id uuid references public.conversations(id) on delete cascade,
 user_id uuid references public.profiles(id) on delete cascade,
 joined_at timestamptz not null default now(),
 primary key(conversation_id,user_id)
);
create table if not exists public.messages (
 id uuid primary key default gen_random_uuid(),
 conversation_id uuid not null references public.conversations(id) on delete cascade,
 sender_id uuid not null references public.profiles(id),
 body text not null check(length(body) between 1 and 5000),
 created_at timestamptz not null default now(),
 read_at timestamptz
);

create table if not exists public.referrals (
 id uuid primary key default gen_random_uuid(),
 referrer_id uuid not null references public.profiles(id),
 referred_user_id uuid not null unique references public.profiles(id),
 reward_amount numeric(14,2) not null default 200,
 status text not null default 'pending' check(status in ('pending','qualified','paid','rejected')),
 created_at timestamptz not null default now(),
 check(referrer_id <> referred_user_id)
);

create table if not exists public.support_tickets (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id),
 subject text not null,
 message text not null,
 fee_amount numeric(14,2) not null default 500,
 payment_status text not null default 'pending' check(payment_status in ('pending','paid','failed')),
 status text not null default 'open' check(status in ('open','in_progress','resolved','closed')),
 created_at timestamptz not null default now()
);

create table if not exists public.subscriptions (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id),
 plan text not null check(plan in ('elite','vil')),
 amount numeric(14,2) not null,
 status text not null default 'pending' check(status in ('pending','active','expired','cancelled')),
 starts_at timestamptz,
 ends_at timestamptz,
 created_at timestamptz not null default now()
);

-- Automatically create a profile and empty wallet for new auth users.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public as $$
begin
 insert into public.profiles(id,full_name,role)
 values(new.id,coalesce(new.raw_user_meta_data->>'full_name',''),coalesce(new.raw_user_meta_data->>'role','customer'))
 on conflict(id) do nothing;
 insert into public.wallets(user_id) values(new.id) on conflict(user_id) do nothing;
 return new;
end; $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.wallets enable row level security;
alter table public.wallet_transactions enable row level security;
alter table public.payment_intents enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;
alter table public.referrals enable row level security;
alter table public.support_tickets enable row level security;
alter table public.subscriptions enable row level security;

-- Profiles: authenticated users can read public profile basics; only owner can update own row.
create policy "profiles readable by authenticated" on public.profiles for select to authenticated using (true);
create policy "profile owner update" on public.profiles for update to authenticated using (auth.uid()=id) with check (auth.uid()=id);

create policy "active products public read" on public.products for select using (status='active' or seller_id=auth.uid());
create policy "seller creates own products" on public.products for insert to authenticated with check (seller_id=auth.uid());
create policy "seller updates own pending products" on public.products for update to authenticated using (seller_id=auth.uid() and status in ('pending','rejected')) with check (seller_id=auth.uid());

create policy "order participants read" on public.orders for select to authenticated using (customer_id=auth.uid() or seller_id=auth.uid());
create policy "customer creates own order" on public.orders for insert to authenticated with check (customer_id=auth.uid());

create policy "wallet owner read" on public.wallets for select to authenticated using (user_id=auth.uid());
create policy "transaction owner read" on public.wallet_transactions for select to authenticated using (user_id=auth.uid());
create policy "payment owner read" on public.payment_intents for select to authenticated using (user_id=auth.uid());

create policy "member reads conversations" on public.conversations for select to authenticated using (
 exists(select 1 from public.conversation_members m where m.conversation_id=id and m.user_id=auth.uid()));
create policy "member reads membership" on public.conversation_members for select to authenticated using (user_id=auth.uid());
create policy "user joins own membership" on public.conversation_members for insert to authenticated with check (user_id=auth.uid());
create policy "members read messages" on public.messages for select to authenticated using (
 exists(select 1 from public.conversation_members m where m.conversation_id=conversation_id and m.user_id=auth.uid()));
create policy "members send messages as self" on public.messages for insert to authenticated with check (
 sender_id=auth.uid() and exists(select 1 from public.conversation_members m where m.conversation_id=conversation_id and m.user_id=auth.uid()));

create policy "referral participants read" on public.referrals for select to authenticated using (referrer_id=auth.uid() or referred_user_id=auth.uid());
create policy "user reads own support tickets" on public.support_tickets for select to authenticated using (user_id=auth.uid());
create policy "user creates own support ticket" on public.support_tickets for insert to authenticated with check (user_id=auth.uid() and payment_status='pending');
create policy "user reads own subscriptions" on public.subscriptions for select to authenticated using (user_id=auth.uid());

-- Do NOT add client-side update policies for wallet balances, payment status, commissions or rewards.
-- Trusted server-side code must verify provider events before writing these financial records.
